// luu bien token
let token = '';
let domain_api = 'http://127.0.0.1:8000/api/';
let domain = 'http://127.0.0.1:8000/';
var exchange_rate = 3.5;

// api get exchange rate
var api_exchange_rate = $.get( domain_api + "option/getexchangerate", function() {
    console.log('api_exchange_rate before done');
})
    .done(function(data) {
        console.log('api_exchange_rate done');
        console.log(data[0].value);
        exchange_rate = data[0].value;
    }).then(createHTML)
    .fail(function() {
        console.log('fail-api_exchange_rate');
        openLogin();
    })
    .always(function() {
        //alert( "finished" );
    });

// api get token
var api_token = $.get( domain_api + "user/gettoken", function() {
	console.log('before done');
})
.done(function(data) {
	console.log('done');
	console.log(data);
})
.fail(function() {
	console.log('fail-may-be-not-login');
    openLogin();
})
.always(function() {
	//alert( "finished" );
});


// function open dathangsieutoc to login
function openLogin(){
    window.open(domain + "backyard/login", "_blank");
};


/**
 * LOGIC dat hang
 */


function countItems() {
    console.log(100);
    console.log($('.ms-yh').find('span.amount').text());
}

//document.getElementById("btnOrder").addEventListener("click", countItems);

document.getElementById("btnOrder").onclick = function() {alert(100);};


/**
 * CREATE HTML
 */

function createHTML() {
    if (window.location.hostname === 'detail.1688.com') {
        console.log('1688');
        create1688_info();
        create1688_buttoncart();
    } else {
        console.log('other');
    }
}

function create1688_buttoncart() {
    // tao div dat-hang
    var div_dat_hang = document.createElement('div');
    div_dat_hang.textContent = "";
    div_dat_hang.setAttribute('class', 'dat-hang dat-hang-st');
    var list = document.getElementsByClassName('obj-sku');
    list[0].after(div_dat_hang);

    // tao div container trong dat-hang
    var div_container = document.createElement('div');
    div_container.textContent = "";
    div_container.setAttribute('class', 'container container-append');
    var list = document.getElementsByClassName('dat-hang-st');
    list[0].appendChild(div_container);

    //tao p warning trong container
    var p_warning = document.createElement('P');
    p_warning.textContent = "Lưu ý: Không sử dụng chức năng dịch ngôn ngữ của google khi thao tác đặt hàng";
    p_warning.setAttribute('class', 'warning');
    var list = document.getElementsByClassName('container-append');
    list[0].appendChild(p_warning);

    //tao label trong container
    var label_btn_reload = document.createElement('LABEL');
    label_btn_reload.textContent = "";
    label_btn_reload.setAttribute('class', 'label-btn-reload');
    var list = document.getElementsByClassName('container-append');
    list[0].appendChild(label_btn_reload);

    // tao the a trong label
    var a_btn_reload = document.createElement('A');
    a_btn_reload.textContent = "Thêm vào giỏ hàng";
    a_btn_reload.setAttribute('class', 'button button-large button-important');
    a_btn_reload.setAttribute('id', 'btnOrder');
    var list = document.getElementsByClassName('label-btn-reload');
    list[0].appendChild(a_btn_reload);
}

function create1688_info(){
    // tao div info
    var div_info = document.createElement('div');
    div_info.textContent = "";
    div_info.setAttribute('class', 'info info-append');
    var list = document.getElementsByClassName('d-content');
    list[0].after(div_info);

// tao image logo
    var img_logo = document.createElement('IMG');
    img_logo.src = "https://nguonhang24h.vn/images/logo.png";
    var list = document.getElementsByClassName('info-append');
    list[0].appendChild(img_logo,list[0]);

// tao box-info
    var box_info = document.createElement('div');
    box_info.textContent = "";
    box_info.setAttribute('class', 'box-info box-info-append');
    var list = document.getElementsByClassName('info-append');
    list[0].appendChild(box_info);

// tao ul
    var ul = document.createElement('ul');
    ul.textContent = "";
    ul.setAttribute('class', 'form-group ul-meta');
    var list = document.getElementsByClassName('box-info-append');
    list[0].appendChild(ul);

    // tao li
    // price_box[0].lastChild.previousSibling.innerText
    let price_cn = 0;
    var li_1 = document.createElement('LI');
    let price_box1 = document.getElementsByClassName('price-original-sku');
    if(price_box1[0] !== undefined) {
        price_cn = price_box1[0].lastChild.previousSibling.innerText;
        // li_1.textContent = "Gia ban " + price_cn + " te";
        // li_1.setAttribute('class', 'form-group');
        // var list = document.getElementsByClassName('ul-meta');
        // list[0].appendChild(li_1);
    } else {
        var span_price = document.getElementsByClassName('value price-length-6');
        price_cn = span_price[0].innerText;
    }

    //#####
    // tao li gia ban
    var li_2 = document.createElement('LI');
    li_2.textContent = "";
    li_2.setAttribute('class', 'form-group li-price-vn');
    var list = document.getElementsByClassName('ul-meta');
    list[0].appendChild(li_2);

    // label gia san pham vn
    var label_price_vn = document.createElement('LABEL');
    label_price_vn.textContent = "Giá bán: ";
    var list = document.getElementsByClassName('li-price-vn');
    list[0].appendChild(label_price_vn);

    // span gia san pham vn
    var span_price_vn = document.createElement('SPAN');
    span_price_vn.textContent = "";
    span_price_vn.setAttribute('class', 'right span-price-vn');
    var list = document.getElementsByClassName('li-price-vn');
    list[0].appendChild(span_price_vn);

    // b gia san pham vn
    var b_price_vn = document.createElement('B');
    var number = price_cn*exchange_rate;
    console.log('price_cn: ' + price_cn);
    console.log('exchange_rate: ' + exchange_rate);
    console.log('number: ' + number);
    var price_vnd =  new Intl.NumberFormat().format(number);
    b_price_vn.textContent = price_vnd + ' đ';
    b_price_vn.setAttribute('class', 'tbe-rate');
    var list = document.getElementsByClassName('span-price-vn');
    list[0].appendChild(b_price_vn);
    //#####

    //#####
    // tao ti gia
    var li_3 = document.createElement('LI');
    li_3.textContent = "";
    li_3.setAttribute('class', 'form-group li-exchange');
    var list = document.getElementsByClassName('ul-meta');
    list[0].appendChild(li_3);

    // label ti gia
    var label_exchange = document.createElement('LABEL');
    label_exchange.textContent = "Giá bán: ";
    var list = document.getElementsByClassName('li-exchange');
    list[0].appendChild(label_exchange);

    // span ti gia
    var span_exchange = document.createElement('SPAN');
    span_exchange.textContent = "";
    span_exchange.setAttribute('class', 'right span-exchange');
    var list = document.getElementsByClassName('li-exchange');
    list[0].appendChild(span_exchange);

    // b ti gia
    var b_exchange = document.createElement('B');
    b_exchange.textContent = exchange_rate + ' đ/tệ';
    var list = document.getElementsByClassName('span-exchange');
    list[0].appendChild(b_exchange);
    //#####


	// tao li ma san pham
    var li_3 = document.createElement('LI');
    li_3.textContent = "";
    li_3.setAttribute('class', 'form-group li-ma-sp');
    var list = document.getElementsByClassName('ul-meta');
    list[0].appendChild(li_3);

    var label_masp = document.createElement('LABEL');
    label_masp.textContent = "Mã sản phẩm: ";
    var list = document.getElementsByClassName('li-ma-sp');
    list[0].appendChild(label_masp);

    var span_masp = document.createElement('SPAN');
    var list = document.getElementsByClassName('li-ma-sp');
    span_masp.setAttribute('class', 'span-masp');
    list[0].appendChild(span_masp);

    var b_masp = document.createElement('B');
    var masp = document.getElementById('offer_video_refKey');
    var masp_text = masp.value.split('-')[1];
    b_masp.textContent = masp_text;
    b_masp.setAttribute('class', 'color-blue');
    var list = document.getElementsByClassName('span-masp');
    list[0].appendChild(b_masp);
}