<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShippingCode extends Model
{
    protected $table = 'shipping_code';

}
