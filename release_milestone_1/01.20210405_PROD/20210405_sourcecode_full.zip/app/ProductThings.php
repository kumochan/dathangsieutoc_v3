<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductThings extends Model
{
    //
}
