<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerProduct extends Model
{
    //
    public $timestamps = false;
    protected $table = 'customer_products';
}
