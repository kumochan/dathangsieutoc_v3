<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Thing;

class ThingController extends BackendController
{

}
