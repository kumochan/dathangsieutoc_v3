<?php

namespace App;

class ConstValue
{
   CONST ORDER_STATUS_1 = "Tạo đơn hàng";
   CONST ORDER_STATUS_2 = "Chờ đặt cọc";
   CONST ORDER_STATUS_3 = "Đã đặt cọc";
   CONST ORDER_STATUS_4 = "Đang đặt hàng";
   CONST ORDER_STATUS_5 = "Đã đặt hàng";
   CONST ORDER_STATUS_6 = "Shop xưởng giao";
   CONST ORDER_STATUS_7 = "Đang vận chuyển";
   CONST ORDER_STATUS_8 = "Kho VN nhận";
   CONST ORDER_STATUS_9 = "Đã trả hàng";
   CONST ORDER_STATUS_10 = "Đã Hủy";
   CONST ORDER_STATUS_11 = 'Đơn hàng khiếu nại';

   CONST ORDER_STATUS_ID_1 = 1;
   CONST ORDER_STATUS_ID_2 = 2;
   CONST ORDER_STATUS_ID_3 = 3;
   CONST ORDER_STATUS_ID_4 = 4;
   CONST ORDER_STATUS_ID_5 = 5;
   CONST ORDER_STATUS_ID_6 = 6;
   CONST ORDER_STATUS_ID_7 = 7;
   CONST ORDER_STATUS_ID_8 = 8;
   CONST ORDER_STATUS_ID_9 = 9;
   CONST ORDER_STATUS_ID_10 = 10;
   CONST ORDER_STATUS_ID_11 = 11;
}